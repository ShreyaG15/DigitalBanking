package com.mob.casestudy.digitalbanking.service;

import com.mob.casestudy.digitalbanking.entity.Customer;
import com.mob.casestudy.digitalbanking.entity.CustomerSecurityImages;
import com.mob.casestudy.digitalbanking.entity.SecurityImages;
import com.mob.casestudy.digitalbanking.exception.CustomerSecurityImageNotFoundException;
import com.mob.casestudy.digitalbanking.repository.CustomerRepository;
import com.mob.casestudy.digitalbanking.repository.CustomerSecurityImagesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Transactional
@Component
public class CustomerSecurityImagesService {

    @Autowired
    CustomerSecurityImagesRepo customerSecurityImagesRepo;
    @Autowired
    CustomerRepository customerRepository;

        public void addImage(){
            CustomerSecurityImages customer1 = new CustomerSecurityImages();
            Customer customer = customerRepository.findByUserName("Sg");
            customer1.setCustomer(customer);
            customer1.setSecurityImageCaption("Cellphone");
            customer1.setCreatedOn(LocalDateTime.now().toString());
           // customer1.setCustomer(customerRepository.findByUserName("Sg"));
            customerSecurityImagesRepo.save(customer1);
        }


    public void validateImages(List<CustomerSecurityImages> customerSecurityImages) {
        if (customerSecurityImages.isEmpty()) {
            throw new CustomerSecurityImageNotFoundException();
        }
    }
}
