package com.mob.casestudy.digitalbanking.exception;

public class CustomerSecurityImageNotFoundException extends RuntimeException{
}
