package com.mob.casestudy.digitalbanking.service;

import com.mob.casestudy.digitalbanking.entity.Customer;
import com.mob.casestudy.digitalbanking.entity.CustomerSecurityImages;
import com.mob.casestudy.digitalbanking.exception.CustomerSecurityImageNotFoundException;
import com.mob.casestudy.digitalbanking.exception.UserNotFoundException;
import com.mob.casestudy.digitalbanking.repository.CustomerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class SecurityImageUserValidation {

    private final CustomerRepository customerRepository;

    public SecurityImageUserValidation(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public Customer validateUser(String username){
        Customer validateByUserName = customerRepository.findByUserName(username);
        if (!customerRepository.existsByUserName(username)){
            throw new UserNotFoundException();
        }
        return validateByUserName;
    }

    public void validateImages(List<CustomerSecurityImages> customerSecurityImages){
        if (customerSecurityImages.isEmpty()){
            throw new CustomerSecurityImageNotFoundException();
        }
    }
}
