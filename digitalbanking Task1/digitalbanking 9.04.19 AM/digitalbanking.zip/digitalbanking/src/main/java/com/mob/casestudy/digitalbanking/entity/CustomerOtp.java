package com.mob.casestudy.digitalbanking.entity;

import com.mob.casestudy.digitalbanking.entity.embeddable.CustomerOtpId;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
public class CustomerOtp {

    @EmbeddedId
    private CustomerOtpId customerOtpId;

    @OneToOne
    @MapsId("customerId")
    private Customer customer;

    @Column(length = 160)
    private String otpMessage;

    @Column(length = 6)
    private String otp;

    @Column(scale = 1)
    private Integer optRetires;

    private LocalDateTime expiresOn;

    private LocalDateTime createdOn;

    public CustomerOtp() {
    }

    public CustomerOtp(String otpMessage, String otp, Integer optRetires, LocalDateTime expiresOn, LocalDateTime createdOn) {
        this.otpMessage = otpMessage;
        this.otp = otp;
        this.optRetires = optRetires;
        this.expiresOn = expiresOn;
        this.createdOn = createdOn;
    }

    public CustomerOtp(CustomerOtpId customerOtpId, String otpMessage, String otp, Integer optRetires, LocalDateTime expiresOn, LocalDateTime createdOn) {
        this.customerOtpId = customerOtpId;
        this.otpMessage = otpMessage;
        this.otp = otp;
        this.optRetires = optRetires;
        this.expiresOn = expiresOn;
        this.createdOn = createdOn;
    }

    public CustomerOtpId getCustomerOtpId() {
        return customerOtpId;
    }

    public void setCustomerOtpId(CustomerOtpId customerOtpId) {
        this.customerOtpId = customerOtpId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getOtpMessage() {
        return otpMessage;
    }

    public void setOtpMessage(String otpMessage) {
        this.otpMessage = otpMessage;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public Integer getOptRetires() {
        return optRetires;
    }

    public void setOptRetires(Integer optRetires) {
        this.optRetires = optRetires;
    }

    public LocalDateTime getExpiresOn() {
        return expiresOn;
    }

    public void setExpiresOn(LocalDateTime expiresOn) {
        this.expiresOn = expiresOn;
    }

    public LocalDateTime getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDateTime createdOn) {
        this.createdOn = createdOn;
    }

}
