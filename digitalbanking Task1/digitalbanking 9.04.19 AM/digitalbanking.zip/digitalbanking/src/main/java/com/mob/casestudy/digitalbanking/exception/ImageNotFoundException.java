package com.mob.casestudy.digitalbanking.exception;

public class ImageNotFoundException extends RuntimeException {
}
