package com.mob.casestudy.digitalbanking.service;

import com.mob.casestudy.digitalbanking.entity.Customer;
import com.mob.casestudy.digitalbanking.entity.enumerator.Language;
import com.mob.casestudy.digitalbanking.entity.enumerator.UserStatus;
import com.mob.casestudy.digitalbanking.exception.UserNotFoundException;
import com.mob.casestudy.digitalbanking.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Component
public class CustomerService {

    @Autowired
    CustomerRepository customerRepository;

//    public void addCustomer(){
//        Customer customerBuilder = Customer.builder().userName("Sg").
//                firstName("Shreya").lastName("Gandhi").phoneNumber("1234567891").
//                email("sgandhi@gmail.com").status(UserStatus.ACTIVE).
//                preferredLanguage(Language.EN).build();
//        customerRepository.save(customerBuilder);
//    }
    public void addCustomer(){
        customerRepository.save(new Customer("Sg","Shreya","Gandhi",
                "1234567891","sgandhi@gmail.com",UserStatus.ACTIVE,Language.EN));
    }

    public Customer validateUser(String username){
        Customer validateByUserName = customerRepository.findByUserName(username);
        if (!customerRepository.existsByUserName(username)){
            throw new UserNotFoundException();
        }
        return validateByUserName;
    }
}
