package com.mob.casestudy.digitalbanking.controller;

import com.mob.casestudy.digitalbanking.dto.CustomerSecurityImagesDto;
import com.mob.casestudy.digitalbanking.entity.Customer;
import com.mob.casestudy.digitalbanking.entity.CustomerSecurityImages;
import com.mob.casestudy.digitalbanking.repository.CustomerRepository;
import com.mob.casestudy.digitalbanking.service.SecurityImageUserValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/customer-service")
public class CustomerSecurityImageController {
    @Autowired
    SecurityImageUserValidation securityImageUserValidation;
    @Autowired
    CustomerRepository customerRepository;
//
//    private final SecurityImageUserValidation userValidation;
//
//    public CustomerSecurityImageController(SecurityImageUserValidation userValidation) {
//        this.userValidation = userValidation;
//    }
//
//
//        @GetMapping("/client-api/v1/customer/{username}")
//    public ResponseEntity<Object> retrieveCustomerByUsername(@PathVariable String userName) {
//            Customer customer = userValidation.validateUser(userName);
//            List<CustomerSecurityImages> list = (List<CustomerSecurityImages>) securityImageUserValidation.validateUser("ABC");
//            userValidation.validateImages(list);
//            List<CustomerSecurityImagesDto> customerSecurityImagesDto = new ArrayList<>();
//            for (CustomerSecurityImages customerSecurityImages:list){
//               customerSecurityImagesDto.add(customerSecurityImages.toDto());
//            }
//            return (ResponseEntity<Object>) customerSecurityImagesDto;
//        }
}
