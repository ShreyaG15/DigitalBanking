package com.mob.casestudy.digitalbanking.entity.enumerator;

public enum UserStatus {
    PENDING,ACTIVE,INACTIVE;
}
