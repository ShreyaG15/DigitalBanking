package com.mob.casestudy.digitalbanking.dto;


import lombok.NoArgsConstructor;
import lombok.ToString;



@NoArgsConstructor
@ToString
public class CustomerSecurityImagesDto {
    private String securityImageId;
    private String securityImageName;
    private String securityImageCaption;
    private String securityImageUrl;

    public CustomerSecurityImagesDto(String securityImageId, String securityImageName, String securityImageCaption, String getSecurityImageUrl) {
        this.securityImageId = securityImageId;
        this.securityImageName = securityImageName;
        this.securityImageCaption = securityImageCaption;
        this.securityImageUrl = getSecurityImageUrl;
    }

    public String getSecurityImageId() {
        return securityImageId;
    }

    public String getSecurityImageName() {
        return securityImageName;
    }

    public String getSecurityImageCaption() {
        return securityImageCaption;
    }

    public String getSecurityImageUrl() {
        return securityImageUrl;
    }
}
