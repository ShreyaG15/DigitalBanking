package com.mob.casestudy.digitalbanking.controller;


import com.mob.casestudy.digitalbanking.dto.SecurityImagesDto;
import com.mob.casestudy.digitalbanking.entity.SecurityImages;
import com.mob.casestudy.digitalbanking.exception.ImageNotFoundException;
import com.mob.casestudy.digitalbanking.repository.SecurityImageRepository;
import com.mob.casestudy.digitalbanking.service.SecurityImageServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/customer-service")
public class SecurityImageController {

    @Autowired
    public SecurityImageServiceImpl securityImageServiceImpl;
    @Autowired
    public SecurityImageRepository securityImageRepository;



    @GetMapping("/service-api/v2/securityImages")
    public List<SecurityImagesDto> getList() {
        List<SecurityImages> list = securityImageServiceImpl.findAll();
        List<SecurityImagesDto> securityImagesDto = new ArrayList<>();
        if (list==null||list.isEmpty()) {
            throw new ImageNotFoundException();
        }
        for (SecurityImages securityImages:list){
            securityImagesDto.add(securityImages.toDto());
        }
        return securityImagesDto;
    }

    @PostMapping("/service-api/v2/securityImages")
    public void createSecurityImage(@RequestBody SecurityImagesDto securityImages) {
    securityImageRepository.save(securityImages.toEntity());
    }
}
