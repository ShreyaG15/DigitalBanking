package com.mob.casestudy.digitalbanking.service;

import com.mob.casestudy.digitalbanking.entity.SecurityImages;
import com.mob.casestudy.digitalbanking.repository.SecurityImageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public class SecurityImageServiceImpl {

    @Autowired
    private SecurityImageRepository securityImageRepository;

    public List<SecurityImages> findAll() {
        return securityImageRepository.findAll();
    }
}

