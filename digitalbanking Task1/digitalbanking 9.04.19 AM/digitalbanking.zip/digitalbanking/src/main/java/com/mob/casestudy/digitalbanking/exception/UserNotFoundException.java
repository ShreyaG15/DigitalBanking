package com.mob.casestudy.digitalbanking.exception;

public class UserNotFoundException extends RuntimeException{

}
