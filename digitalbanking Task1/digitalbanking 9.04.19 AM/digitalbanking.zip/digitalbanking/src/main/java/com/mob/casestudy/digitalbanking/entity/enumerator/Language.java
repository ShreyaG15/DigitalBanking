package com.mob.casestudy.digitalbanking.entity.enumerator;

public enum Language {
    EN,FR,DE;
}
