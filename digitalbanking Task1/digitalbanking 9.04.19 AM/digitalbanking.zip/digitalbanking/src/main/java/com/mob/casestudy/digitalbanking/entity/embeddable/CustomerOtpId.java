package com.mob.casestudy.digitalbanking.entity.embeddable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class CustomerOtpId implements Serializable {

    @Column(length = 36)
    private String customerId;

    private String otpId;

    public CustomerOtpId() {
    }

    public CustomerOtpId(String customerId, String otpId) {
        this.customerId = customerId;
        this.otpId = otpId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getOtpId() {
        return otpId;
    }

    public void setOtpId(String otpId) {
        this.otpId = otpId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CustomerOtpId that = (CustomerOtpId) o;
        return customerId.equals(that.customerId) && otpId.equals(that.otpId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(customerId, otpId);
    }
}
