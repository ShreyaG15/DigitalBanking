package com.mob.casestudy.digitalbanking.service;

public class SecurityImageService {
}
